Dependencies
-REQUIRES Skript (Runs on Skript)
-REQUIRES SkReflect (Required for guns to work)
-REQUIRES skript-yaml (Required for guns data load to work)
-REQUIRES NBT API (Required for guns to work)
-REQUIRES SkQuery (Required for certain features)

Installation
-Install Skript
-Install SkReflect
-Install skript-yaml
-Install NBT API
-Install SkQuery
-Download this plugin file
-Locate "plugins/" in the server files and put the files from the plugin zip file into the designated folder path
-Install Resource Pack from the plugin file (Optional but recommended)